/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leituraxml;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Gustavo
 */
public class Fluxo {

    
    
    private String appName;
    private Long totalSourceBytes;
    private Long totalDestinationBytes;
    private Long totalDestinationPackets;
    private Long totalSourcePackets;
    private String sourcePayloadAsBase64;
    private String sourcePayloadAsUTF;
    private String destinationPayloadAsBase64;
    private String destinationPayloadAsUTF;
    private String direction;
    private String sourceTCPFlagsDescription;
    private String destinationTCPFlagsDescription;
    private String source;
    private String protocolName;
    private int sourcePort;
    private String destination;
    private int destinationPort;
    private Date startDateTime;
    private Date stopDateTime;
    private String Tag;

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Long getTotalSourceBytes() {
        return totalSourceBytes;
    }

    public void setTotalSourceBytes(Long totalSourceBytes) {
        this.totalSourceBytes = totalSourceBytes;
    }

    public Long getTotalDestinationBytes() {
        return totalDestinationBytes;
    }

    public void setTotalDestinationBytes(Long totalDestinationBytes) {
        this.totalDestinationBytes = totalDestinationBytes;
    }

    public Long getTotalDestinationPackets() {
        return totalDestinationPackets;
    }

    public void setTotalDestinationPackets(Long totalDestinationPackets) {
        this.totalDestinationPackets = totalDestinationPackets;
    }

    public Long getTotalSourcePackets() {
        return totalSourcePackets;
    }

    public void setTotalSourcePackets(Long totalSourcePackets) {
        this.totalSourcePackets = totalSourcePackets;
    }

    public String getSourcePayloadAsBase64() {
        return sourcePayloadAsBase64;
    }

    public void setSourcePayloadAsBase64(String sourcePayloadAsBase64) {
        this.sourcePayloadAsBase64 = sourcePayloadAsBase64;
    }

    public String getSourcePayloadAsUTF() {
        return sourcePayloadAsUTF;
    }

    public void setSourcePayloadAsUTF(String sourcePayloadAsUTF) {
        this.sourcePayloadAsUTF = sourcePayloadAsUTF;
    }

    public String getDestinationPayloadAsBase64() {
        return destinationPayloadAsBase64;
    }

    public void setDestinationPayloadAsBase64(String destinationPayloadAsBase64) {
        this.destinationPayloadAsBase64 = destinationPayloadAsBase64;
    }

    public String getDestinationPayloadAsUTF() {
        return destinationPayloadAsUTF;
    }

    public void setDestinationPayloadAsUTF(String destinationPayloadAsUTF) {
        this.destinationPayloadAsUTF = destinationPayloadAsUTF;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getSourceTCPFlagsDescription() {
        return sourceTCPFlagsDescription;
    }

    public void setSourceTCPFlagsDescription(String sourceTCPFlagsDescription) {
        this.sourceTCPFlagsDescription = sourceTCPFlagsDescription;
    }

    public String getDestinationTCPFlagsDescription() {
        return destinationTCPFlagsDescription;
    }

    public void setDestinationTCPFlagsDescription(String destinationTCPFlagsDescription) {
        this.destinationTCPFlagsDescription = destinationTCPFlagsDescription;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getProtocolName() {
        return protocolName;
    }

    public void setProtocolName(String protocolName) {
        this.protocolName = protocolName;
    }

    public int getSourcePort() {
        return sourcePort;
    }

    public void setSourcePort(int sourcePort) {
        this.sourcePort = sourcePort;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getDestinationPort() {
        return destinationPort;
    }

    public void setDestinationPort(int destinationPort) {
        this.destinationPort = destinationPort;
    }

    public Date getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(Date startDateTime) {
        this.startDateTime = startDateTime;
    }

    public Date getStopDateTime() {
        return stopDateTime;
    }

    public void setStopDateTime(Date stopDateTime) {
        this.stopDateTime = stopDateTime;
    }

    public String getTag() {
        return Tag;
    }

    public void setTag(String Tag) {
        this.Tag = Tag;
    }
    
    static List<Fluxo> getAttack(List<Fluxo> teste) {
        List<Fluxo> attacks = new ArrayList<>();
        
        for(Fluxo a:teste)
        {
            if(a.getTag().equals("Attack"))
                attacks.add(a);
        }
        return attacks;
    }

}
