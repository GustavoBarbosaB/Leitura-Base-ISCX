/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leituraxml;

import java.util.List;
import javax.swing.JFrame;


public class BaseISCX {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      LerXML ok = new LerXML();
      List<Fluxo> teste;
      teste = ok.ler(); 
      
      Grafico chart = new Grafico("Dados Base ISCX",teste);
      chart.pack();
      chart.setLocationRelativeTo(null);
      chart.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      chart.setVisible(true);
}
    
   /* public List<Fluxo> separaFluxos(List<Fluxo> base, String tag, )
    {
        
        
    }*/

}