/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leituraxml;

import com.thoughtworks.xstream.*;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author Gustavo
 */
public class LerXML {
   

    public List<Fluxo> ler(){
    try {
    XStream stream = new XStream(new DomDriver());
    
    stream.alias("fluxos", List.class);    
    stream.alias("TestbedMonJun14Flows",Fluxo.class);
    stream.registerConverter(new ConverteData());
    
    BufferedReader input = new BufferedReader(new FileReader("teste.xml"));
    List<Fluxo> fromXML = (List<Fluxo>) stream.fromXML(input);   
    return fromXML;
    } catch (IOException ex) {
         ex.printStackTrace();
    }
        return null;

    }
}
